import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ProblemsProvider } from './context/ProblemsContext';
import { AuthProvider } from './context/AuthContext';
import Layout from './components/Layout/Layout';
import Dashboard from './pages/Dashboard/Dashboard';
import ProblemsList from './pages/Problems/ProblemsList';
import ProblemDetail from './pages/Problems/ProblemDetail';
import CreateProblem from './pages/Problems/CreateProblem';
import Analytics from './pages/Analytics/Analytics';
import Login from './pages/Auth/Login';
import NotFound from './pages/NotFound/NotFound';
import ProtectedRoute from './components/Auth/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <ProblemsProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/problems" element={<ProblemsList />} />
              <Route path="/problems/:id" element={<ProblemDetail />} />
              <Route path="/problems/new" element={<CreateProblem />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </Router>
      </ProblemsProvider>
    </AuthProvider>
  );
}

export default App;