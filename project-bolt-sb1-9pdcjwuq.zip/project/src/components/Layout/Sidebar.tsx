import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  AlertCircle, 
  Plus, 
  BarChart2, 
  Filter,
  Settings,
  HelpCircle,
  LayoutDashboard,
  Factory,
  Wrench
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types/types';

const Sidebar: React.FC = () => {
  const { user } = useAuth();
  
  const isAdmin = user?.role === UserRole.ADMIN;
  const isEngineerOrAbove = user?.role === UserRole.ENGINEER || 
    user?.role === UserRole.SUPERVISOR || 
    user?.role === UserRole.ADMIN;

  return (
    <div className="bg-blue-900 text-white w-64 flex-shrink-0 hidden md:block">
      <div className="h-16 flex items-center justify-center border-b border-blue-800">
        <div className="flex items-center space-x-2">
          <Factory size={24} />
          <span className="text-xl font-bold">AutoTrack</span>
        </div>
      </div>
      
      <nav className="mt-5 px-2">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
              isActive
                ? 'bg-blue-800 text-white'
                : 'text-blue-100 hover:bg-blue-800'
            }`
          }
        >
          <Home className="mr-3 h-5 w-5" />
          Dashboard
        </NavLink>
        
        <NavLink
          to="/problems"
          className={({ isActive }) =>
            `group flex items-center px-2 py-2 text-sm font-medium rounded-md mt-1 transition-colors ${
              isActive
                ? 'bg-blue-800 text-white'
                : 'text-blue-100 hover:bg-blue-800'
            }`
          }
        >
          <AlertCircle className="mr-3 h-5 w-5" />
          Problems
        </NavLink>
        
        <NavLink
          to="/problems/new"
          className={({ isActive }) =>
            `group flex items-center px-2 py-2 text-sm font-medium rounded-md mt-1 transition-colors ${
              isActive
                ? 'bg-blue-800 text-white'
                : 'text-blue-100 hover:bg-blue-800'
            }`
          }
        >
          <Plus className="mr-3 h-5 w-5" />
          New Problem
        </NavLink>
        
        <NavLink
          to="/analytics"
          className={({ isActive }) =>
            `group flex items-center px-2 py-2 text-sm font-medium rounded-md mt-1 transition-colors ${
              isActive
                ? 'bg-blue-800 text-white'
                : 'text-blue-100 hover:bg-blue-800'
            }`
          }
        >
          <BarChart2 className="mr-3 h-5 w-5" />
          Analytics
        </NavLink>
        
        {isEngineerOrAbove && (
          <div className="mt-8">
            <h3 className="px-3 text-xs font-semibold text-blue-200 uppercase tracking-wider">
              Advanced
            </h3>
            <div className="mt-1 space-y-1">
              <NavLink
                to="/filter-management"
                className={({ isActive }) =>
                  `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                    isActive
                      ? 'bg-blue-800 text-white'
                      : 'text-blue-100 hover:bg-blue-800'
                  }`
                }
              >
                <Filter className="mr-3 h-5 w-5" />
                Filter Management
              </NavLink>
              
              {isAdmin && (
                <NavLink
                  to="/settings"
                  className={({ isActive }) =>
                    `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                      isActive
                        ? 'bg-blue-800 text-white'
                        : 'text-blue-100 hover:bg-blue-800'
                    }`
                  }
                >
                  <Settings className="mr-3 h-5 w-5" />
                  Settings
                </NavLink>
              )}
            </div>
          </div>
        )}
        
        <div className="mt-auto pt-8">
          <NavLink
            to="/maintenance"
            className={({ isActive }) =>
              `group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ${
                isActive
                  ? 'bg-blue-800 text-white'
                  : 'text-blue-100 hover:bg-blue-800'
              }`
            }
          >
            <Wrench className="mr-3 h-5 w-5" />
            Maintenance
          </NavLink>
          
          <NavLink
            to="/help"
            className={({ isActive }) =>
              `group flex items-center px-2 py-2 text-sm font-medium rounded-md mt-1 transition-colors ${
                isActive
                  ? 'bg-blue-800 text-white'
                  : 'text-blue-100 hover:bg-blue-800'
              }`
            }
          >
            <HelpCircle className="mr-3 h-5 w-5" />
            Help & Support
          </NavLink>
        </div>
      </nav>
    </div>
  );
};

export default Sidebar;