import React from 'react';
import { Problem } from '../../types/types';
import { Clock, AlertTriangle, Check, FileText, Paperclip } from 'lucide-react';
import { formatDistance } from 'date-fns';

interface ProblemCardProps {
  problem: Problem;
  onClick: (id: string) => void;
}

const ProblemCard: React.FC<ProblemCardProps> = ({ problem, onClick }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-red-100 text-red-800';
      case 'in_progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'critical':
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      case 'medium':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'low':
        return <AlertTriangle className="h-5 w-5 text-blue-500" />;
      default:
        return null;
    }
  };

  return (
    <div 
      className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200 cursor-pointer"
      onClick={() => onClick(problem.id)}
    >
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(problem.status)}`}>
            {problem.status === 'in_progress' ? 'In Progress' : problem.status.charAt(0).toUpperCase() + problem.status.slice(1)}
          </span>
          {getPriorityIcon(problem.priority)}
        </div>
        
        <h3 className="text-lg font-medium text-gray-900 mb-1">{problem.title}</h3>
        
        <p className="text-sm text-gray-500 mb-4 line-clamp-2">{problem.description}</p>
        
        <div className="flex items-center text-xs text-gray-500 space-x-4">
          <span className="inline-flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            {formatDistance(new Date(problem.createdAt), new Date(), { addSuffix: true })}
          </span>
          
          {problem.department && (
            <span className="inline-flex items-center">
              <FileText className="h-4 w-4 mr-1" />
              {problem.department}
            </span>
          )}
          
          {problem.attachments && problem.attachments.length > 0 && (
            <span className="inline-flex items-center">
              <Paperclip className="h-4 w-4 mr-1" />
              {problem.attachments.length}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProblemCard;