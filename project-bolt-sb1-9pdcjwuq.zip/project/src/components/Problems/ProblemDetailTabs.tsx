import React, { useState } from 'react';
import { Problem } from '../../types/types';
import { 
  FileText, 
  Search, 
  CheckSquare, 
  Paperclip, 
  MessageSquare, 
  AlertTriangle, 
  Clock 
} from 'lucide-react';
import { format } from 'date-fns';

interface ProblemDetailTabsProps {
  problem: Problem;
}

const ProblemDetailTabs: React.FC<ProblemDetailTabsProps> = ({ problem }) => {
  const [activeTab, setActiveTab] = useState('description');

  return (
    <div className="bg-white shadow-sm rounded-lg overflow-hidden">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex">
          <button
            className={`py-4 px-6 inline-flex items-center text-sm font-medium border-b-2 ${
              activeTab === 'description'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('description')}
          >
            <FileText className="mr-2 h-5 w-5" />
            Description
          </button>
          
          <button
            className={`py-4 px-6 inline-flex items-center text-sm font-medium border-b-2 ${
              activeTab === 'rootCause'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('rootCause')}
          >
            <Search className="mr-2 h-5 w-5" />
            Root Cause
          </button>
          
          <button
            className={`py-4 px-6 inline-flex items-center text-sm font-medium border-b-2 ${
              activeTab === 'actions'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('actions')}
          >
            <CheckSquare className="mr-2 h-5 w-5" />
            Actions
          </button>
          
          <button
            className={`py-4 px-6 inline-flex items-center text-sm font-medium border-b-2 ${
              activeTab === 'attachments'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('attachments')}
          >
            <Paperclip className="mr-2 h-5 w-5" />
            Attachments
          </button>
          
          <button
            className={`py-4 px-6 inline-flex items-center text-sm font-medium border-b-2 ${
              activeTab === 'comments'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('comments')}
          >
            <MessageSquare className="mr-2 h-5 w-5" />
            Comments
          </button>
        </nav>
      </div>
      
      <div className="p-6">
        {activeTab === 'description' && (
          <div>
            <div className="mb-6">
              <h3 className="text-lg font-medium text-gray-900">Problem Details</h3>
              <p className="mt-2 text-gray-600">{problem.description}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <h4 className="text-sm font-medium text-gray-500">Department</h4>
                <p className="mt-1 text-sm text-gray-900">{problem.department}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Report Number</h4>
                <p className="mt-1 text-sm text-gray-900">{problem.reportNumber || 'N/A'}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Created By</h4>
                <p className="mt-1 text-sm text-gray-900">{problem.createdBy}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Assigned To</h4>
                <p className="mt-1 text-sm text-gray-900">{problem.assignedTo || 'Unassigned'}</p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Created At</h4>
                <p className="mt-1 text-sm text-gray-900">
                  {format(new Date(problem.createdAt), 'PPP p')}
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Last Updated</h4>
                <p className="mt-1 text-sm text-gray-900">
                  {format(new Date(problem.updatedAt), 'PPP p')}
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Status</h4>
                <p className="mt-1">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    problem.status === 'open' ? 'bg-red-100 text-red-800' :
                    problem.status === 'in_progress' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {problem.status === 'in_progress' ? 'In Progress' : problem.status.charAt(0).toUpperCase() + problem.status.slice(1)}
                  </span>
                </p>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-500">Priority</h4>
                <p className="mt-1 flex items-center">
                  <AlertTriangle className={`h-4 w-4 mr-1 ${
                    problem.priority === 'critical' ? 'text-red-600' :
                    problem.priority === 'high' ? 'text-orange-500' :
                    problem.priority === 'medium' ? 'text-yellow-500' :
                    'text-blue-500'
                  }`} />
                  <span className="text-sm text-gray-900 capitalize">{problem.priority}</span>
                </p>
              </div>
            </div>
            
            {problem.tags && problem.tags.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Tags</h4>
                <div className="flex flex-wrap gap-2">
                  {problem.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
            
            {(problem.impactLevel || problem.downtime !== undefined) && (
              <div className="mb-6">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Impact</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {problem.impactLevel && (
                    <div>
                      <h5 className="text-xs font-medium text-gray-500">Impact Level</h5>
                      <p className="mt-1 text-sm text-gray-900 capitalize">{problem.impactLevel}</p>
                    </div>
                  )}
                  
                  {problem.downtime !== undefined && (
                    <div>
                      <h5 className="text-xs font-medium text-gray-500">Downtime</h5>
                      <p className="mt-1 text-sm text-gray-900">
                        {problem.downtime} minutes ({Math.floor(problem.downtime / 60)}h {problem.downtime % 60}m)
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'rootCause' && (
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">Root Cause Analysis</h3>
            
            {problem.rootCause ? (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-600">{problem.rootCause}</p>
              </div>
            ) : (
              <div className="bg-yellow-50 p-4 rounded-lg text-center">
                <p className="text-yellow-700">No root cause analysis has been documented yet.</p>
                <button className="mt-2 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                  Add Root Cause
                </button>
              </div>
            )}
            
            {problem.solution && (
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Solution</h3>
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-gray-600">{problem.solution}</p>
                </div>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'actions' && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Action Items</h3>
              <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                Add Action Item
              </button>
            </div>
            
            {problem.actionItems && problem.actionItems.length > 0 ? (
              <div className="space-y-4">
                {problem.actionItems.map((action) => (
                  <div key={action.id} className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start">
                        <div className={`flex-shrink-0 h-5 w-5 rounded-full ${action.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-gray-900">{action.description}</p>
                          <div className="mt-1 flex items-center text-sm text-gray-500">
                            <span>Assigned to {action.assignedTo}</span>
                            {action.dueDate && (
                              <span className="ml-4 flex items-center">
                                <Clock className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                Due {format(new Date(action.dueDate), 'MMM d, yyyy')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="ml-4 flex-shrink-0">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            action.status === 'completed'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {action.status === 'completed' ? 'Completed' : 'Pending'}
                        </span>
                      </div>
                    </div>
                    
                    {action.completedAt && (
                      <div className="mt-2 ml-8 text-xs text-gray-500">
                        Completed on {format(new Date(action.completedAt), 'PPP')}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 text-center rounded-lg">
                <p className="text-gray-500">No action items have been added yet.</p>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'attachments' && (
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Attachments</h3>
              <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                Upload Attachment
              </button>
            </div>
            
            {problem.attachments && problem.attachments.length > 0 ? (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {problem.attachments.map((attachment) => (
                  <div key={attachment.id} className="bg-white border border-gray-200 rounded-lg p-4 flex items-start">
                    <div className="flex-shrink-0 h-10 w-10 rounded bg-gray-100 flex items-center justify-center">
                      <FileText className="h-5 w-5 text-gray-500" />
                    </div>
                    <div className="ml-3 flex-1 min-w-0">
                      <p className="text-sm font-medium text-blue-600 truncate">{attachment.name}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        Uploaded by {attachment.uploadedBy} on {format(new Date(attachment.uploadedAt), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 text-center rounded-lg">
                <p className="text-gray-500">No attachments have been added yet.</p>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'comments' && (
          <div>
            <div className="mb-4">
              <h3 className="text-lg font-medium text-gray-900">Comments</h3>
            </div>
            
            <div className="mb-6">
              <textarea
                rows={3}
                className="shadow-sm block w-full focus:ring-blue-500 focus:border-blue-500 sm:text-sm border border-gray-300 rounded-md"
                placeholder="Add a comment..."
              ></textarea>
              <div className="mt-2 flex justify-end">
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Post Comment
                </button>
              </div>
            </div>
            
            {problem.comments && problem.comments.length > 0 ? (
              <div className="space-y-6">
                {problem.comments.map((comment) => (
                  <div key={comment.id} className="flex space-x-3">
                    <div className="flex-shrink-0">
                      {comment.userAvatar ? (
                        <img
                          className="h-10 w-10 rounded-full"
                          src={comment.userAvatar}
                          alt={comment.userName}
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-gray-300 flex items-center justify-center">
                          <span className="text-gray-600">{comment.userName.charAt(0)}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex-1 bg-gray-50 rounded-lg px-4 py-3 sm:px-6">
                      <div className="flex justify-between">
                        <h3 className="text-sm font-medium text-gray-900">{comment.userName}</h3>
                        <p className="text-xs text-gray-500">
                          {format(new Date(comment.createdAt), 'MMM d, yyyy h:mm a')}
                        </p>
                      </div>
                      <div className="mt-1 text-sm text-gray-700">
                        <p>{comment.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-gray-50 p-8 text-center rounded-lg">
                <p className="text-gray-500">No comments yet. Be the first to add one!</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProblemDetailTabs;