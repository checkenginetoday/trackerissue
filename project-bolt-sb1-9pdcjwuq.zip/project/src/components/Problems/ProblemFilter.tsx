import React, { useState } from 'react';
import { Department, ProblemStatus } from '../../types/types';
import { Search, Filter, X } from 'lucide-react';

interface ProblemFilterProps {
  onFilter: (filters: {
    search?: string;
    department?: Department;
    status?: ProblemStatus;
    dateFrom?: Date;
    dateTo?: Date;
  }) => void;
}

const ProblemFilter: React.FC<ProblemFilterProps> = ({ onFilter }) => {
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState<Department | undefined>(undefined);
  const [status, setStatus] = useState<ProblemStatus | undefined>(undefined);
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [isAdvancedFilterOpen, setIsAdvancedFilterOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    onFilter({ search: e.target.value, department, status, dateFrom: dateFrom ? new Date(dateFrom) : undefined, dateTo: dateTo ? new Date(dateTo) : undefined });
  };

  const handleDepartmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === '' ? undefined : e.target.value as Department;
    setDepartment(value);
    onFilter({ search, department: value, status, dateFrom: dateFrom ? new Date(dateFrom) : undefined, dateTo: dateTo ? new Date(dateTo) : undefined });
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === '' ? undefined : e.target.value as ProblemStatus;
    setStatus(value);
    onFilter({ search, department, status: value, dateFrom: dateFrom ? new Date(dateFrom) : undefined, dateTo: dateTo ? new Date(dateTo) : undefined });
  };

  const handleDateFromChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDateFrom(e.target.value);
    onFilter({ search, department, status, dateFrom: e.target.value ? new Date(e.target.value) : undefined, dateTo: dateTo ? new Date(dateTo) : undefined });
  };

  const handleDateToChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDateTo(e.target.value);
    onFilter({ search, department, status, dateFrom: dateFrom ? new Date(dateFrom) : undefined, dateTo: e.target.value ? new Date(e.target.value) : undefined });
  };

  const clearFilters = () => {
    setSearch('');
    setDepartment(undefined);
    setStatus(undefined);
    setDateFrom('');
    setDateTo('');
    onFilter({});
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
      <div className="flex items-center">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            placeholder="Search problems..."
            value={search}
            onChange={handleSearchChange}
          />
        </div>
        
        <button
          type="button"
          className="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          onClick={() => setIsAdvancedFilterOpen(!isAdvancedFilterOpen)}
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </button>
        
        {(search || department || status || dateFrom || dateTo) && (
          <button
            type="button"
            className="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-red-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            onClick={clearFilters}
          >
            <X className="h-4 w-4 mr-2" />
            Clear
          </button>
        )}
      </div>
      
      {isAdvancedFilterOpen && (
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label htmlFor="department" className="block text-sm font-medium text-gray-700">
              Department
            </label>
            <select
              id="department"
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
              value={department || ''}
              onChange={handleDepartmentChange}
            >
              <option value="">All Departments</option>
              {Object.values(Department).map((dept) => (
                <option key={dept} value={dept}>
                  {dept.charAt(0).toUpperCase() + dept.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700">
              Status
            </label>
            <select
              id="status"
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
              value={status || ''}
              onChange={handleStatusChange}
            >
              <option value="">All Statuses</option>
              {Object.values(ProblemStatus).map((stat) => (
                <option key={stat} value={stat}>
                  {stat === 'in_progress' ? 'In Progress' : stat.charAt(0).toUpperCase() + stat.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="dateFrom" className="block text-sm font-medium text-gray-700">
              From Date
            </label>
            <input
              type="date"
              id="dateFrom"
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
              value={dateFrom}
              onChange={handleDateFromChange}
            />
          </div>
          
          <div>
            <label htmlFor="dateTo" className="block text-sm font-medium text-gray-700">
              To Date
            </label>
            <input
              type="date"
              id="dateTo"
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
              value={dateTo}
              onChange={handleDateToChange}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ProblemFilter;