import React, { createContext, useState, useContext, useEffect } from 'react';
import { mockProblems } from '../data/mockData';
import { Problem, Department, ProblemStatus } from '../types/types';

interface ProblemsContextType {
  problems: Problem[];
  filteredProblems: Problem[];
  loading: boolean;
  error: string | null;
  addProblem: (problem: Omit<Problem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateProblem: (id: string, updates: Partial<Problem>) => void;
  deleteProblem: (id: string) => void;
  filterProblems: (filters: {
    search?: string;
    department?: Department;
    status?: ProblemStatus;
    dateFrom?: Date;
    dateTo?: Date;
  }) => void;
}

const ProblemsContext = createContext<ProblemsContextType | undefined>(undefined);

export const ProblemsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [problems, setProblems] = useState<Problem[]>([]);
  const [filteredProblems, setFilteredProblems] = useState<Problem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simulate API call
    const fetchProblems = () => {
      try {
        setLoading(true);
        // In a real app, this would be an API call
        setTimeout(() => {
          setProblems(mockProblems);
          setFilteredProblems(mockProblems);
          setLoading(false);
        }, 1000);
      } catch (err) {
        setError('Failed to fetch problems');
        setLoading(false);
      }
    };

    fetchProblems();
  }, []);

  const addProblem = (problem: Omit<Problem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProblem: Problem = {
      ...problem,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setProblems([newProblem, ...problems]);
    setFilteredProblems([newProblem, ...filteredProblems]);
  };

  const updateProblem = (id: string, updates: Partial<Problem>) => {
    const updatedProblems = problems.map((problem) =>
      problem.id === id
        ? { ...problem, ...updates, updatedAt: new Date() }
        : problem
    );
    setProblems(updatedProblems);
    setFilteredProblems(
      filteredProblems.map((problem) =>
        problem.id === id
          ? { ...problem, ...updates, updatedAt: new Date() }
          : problem
      )
    );
  };

  const deleteProblem = (id: string) => {
    setProblems(problems.filter((problem) => problem.id !== id));
    setFilteredProblems(filteredProblems.filter((problem) => problem.id !== id));
  };

  const filterProblems = (filters: {
    search?: string;
    department?: Department;
    status?: ProblemStatus;
    dateFrom?: Date;
    dateTo?: Date;
  }) => {
    let filtered = [...problems];

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(
        (problem) =>
          problem.title.toLowerCase().includes(searchLower) ||
          problem.description.toLowerCase().includes(searchLower)
      );
    }

    if (filters.department) {
      filtered = filtered.filter((problem) => problem.department === filters.department);
    }

    if (filters.status) {
      filtered = filtered.filter((problem) => problem.status === filters.status);
    }

    if (filters.dateFrom) {
      filtered = filtered.filter(
        (problem) => new Date(problem.createdAt) >= new Date(filters.dateFrom)
      );
    }

    if (filters.dateTo) {
      filtered = filtered.filter(
        (problem) => new Date(problem.createdAt) <= new Date(filters.dateTo)
      );
    }

    setFilteredProblems(filtered);
  };

  return (
    <ProblemsContext.Provider
      value={{
        problems,
        filteredProblems,
        loading,
        error,
        addProblem,
        updateProblem,
        deleteProblem,
        filterProblems,
      }}
    >
      {children}
    </ProblemsContext.Provider>
  );
};

export const useProblems = () => {
  const context = useContext(ProblemsContext);
  if (context === undefined) {
    throw new Error('useProblems must be used within a ProblemsProvider');
  }
  return context;
};