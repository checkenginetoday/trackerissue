import React, { useState } from 'react';
import { useProblems } from '../../context/ProblemsContext';
import { Department, ProblemStatus } from '../../types/types';
import { Download, Calendar, BarChart2, FileText } from 'lucide-react';

const Analytics: React.FC = () => {
  const { problems } = useProblems();
  const [dateRange, setDateRange] = useState('month');

  // Calculate problems by department
  const problemsByDepartment = Object.values(Department).map(dept => {
    const count = problems.filter(p => p.department === dept).length;
    return { department: dept, count };
  }).sort((a, b) => b.count - a.count);

  // Calculate problems by status
  const problemsByStatus = {
    open: problems.filter(p => p.status === ProblemStatus.OPEN).length,
    inProgress: problems.filter(p => p.status === ProblemStatus.IN_PROGRESS).length,
    resolved: problems.filter(p => p.status === ProblemStatus.RESOLVED).length,
  };

  // Calculate average resolution time (in days)
  const resolvedProblems = problems.filter(p => p.status === ProblemStatus.RESOLVED);
  const avgResolutionTime = resolvedProblems.length > 0
    ? resolvedProblems.reduce((sum, p) => {
        const created = new Date(p.createdAt).getTime();
        const updated = new Date(p.updatedAt).getTime();
        return sum + (updated - created) / (1000 * 60 * 60 * 24); // Convert ms to days
      }, 0) / resolvedProblems.length
    : 0;

  // Calculate total downtime (in hours)
  const totalDowntime = problems.reduce((sum, p) => sum + (p.downtime || 0), 0) / 60;

  // Calculate priority distribution
  const priorityDistribution = {
    critical: problems.filter(p => p.priority === 'critical').length,
    high: problems.filter(p => p.priority === 'high').length,
    medium: problems.filter(p => p.priority === 'medium').length,
    low: problems.filter(p => p.priority === 'low').length,
  };

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-6">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            Analytics
          </h1>
        </div>
        <div className="mt-4 flex md:mt-0 md:ml-4 space-x-3">
          <div>
            <select
              id="dateRange"
              className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
            >
              <option value="week">Last Week</option>
              <option value="month">Last Month</option>
              <option value="quarter">Last Quarter</option>
              <option value="year">Last Year</option>
              <option value="all">All Time</option>
            </select>
          </div>
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Download className="-ml-1 mr-2 h-5 w-5 text-gray-500" />
            Export
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Problems</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{problems.length}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <BarChart2 className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Resolution Rate</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">
                      {problems.length > 0
                        ? Math.round((problemsByStatus.resolved / problems.length) * 100)
                        : 0}%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-yellow-100 rounded-md p-3">
                <Calendar className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Avg. Resolution Time</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">
                      {avgResolutionTime.toFixed(1)} days
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-red-100 rounded-md p-3">
                <BarChart2 className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Total Downtime</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">
                      {totalDowntime.toFixed(1)} hours
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Problems by Department</h2>
          <div className="space-y-4">
            {problemsByDepartment.map(({ department, count }) => (
              <div key={department} className="relative">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-600 capitalize">{department}</span>
                  <span className="text-sm font-medium text-gray-900">{count}</span>
                </div>
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-100">
                  <div
                    style={{
                      width: `${Math.min(100, (count / Math.max(...problemsByDepartment.map(d => d.count))) * 100)}%`
                    }}
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Problem Status Distribution</h2>
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-red-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-red-800 mb-2">Open</h3>
              <p className="text-2xl font-bold text-red-600">{problemsByStatus.open}</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-yellow-800 mb-2">In Progress</h3>
              <p className="text-2xl font-bold text-yellow-600">{problemsByStatus.inProgress}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-green-800 mb-2">Resolved</h3>
              <p className="text-2xl font-bold text-green-600">{problemsByStatus.resolved}</p>
            </div>
          </div>
          
          <h2 className="text-lg font-medium text-gray-900 mb-4">Priority Distribution</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-red-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-red-800 mb-2">Critical</h3>
              <p className="text-2xl font-bold text-red-600">{priorityDistribution.critical}</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-orange-800 mb-2">High</h3>
              <p className="text-2xl font-bold text-orange-600">{priorityDistribution.high}</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-yellow-800 mb-2">Medium</h3>
              <p className="text-2xl font-bold text-yellow-600">{priorityDistribution.medium}</p>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg text-center">
              <h3 className="text-sm font-medium text-blue-800 mb-2">Low</h3>
              <p className="text-2xl font-bold text-blue-600">{priorityDistribution.low}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;