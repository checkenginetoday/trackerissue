import React from 'react';
import { useProblems } from '../../context/ProblemsContext';
import { ProblemStatus, Department } from '../../types/types';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart2, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  Calendar, 
  TrendingUp, 
  AlertTriangle 
} from 'lucide-react';
import ProblemCard from '../../components/Problems/ProblemCard';

const Dashboard: React.FC = () => {
  const { problems, loading } = useProblems();
  const navigate = useNavigate();

  const openProblems = problems.filter(p => p.status === ProblemStatus.OPEN);
  const inProgressProblems = problems.filter(p => p.status === ProblemStatus.IN_PROGRESS);
  const resolvedProblems = problems.filter(p => p.status === ProblemStatus.RESOLVED);
  
  const recentProblems = [...problems].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  ).slice(0, 3);
  
  const priorityIssues = [...problems].filter(p => 
    p.priority === 'critical' || p.priority === 'high'
  ).slice(0, 3);

  const departmentCounts = problems.reduce((acc, problem) => {
    acc[problem.department] = (acc[problem.department] || 0) + 1;
    return acc;
  }, {} as Record<Department, number>);

  const handleProblemClick = (id: string) => {
    navigate(`/problems/${id}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="loader">Loading...</div>
      </div>
    );
  }

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-6">
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
            Dashboard
          </h1>
        </div>
        <div className="mt-4 flex md:mt-0 md:ml-4">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-900 hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            onClick={() => navigate('/problems/new')}
          >
            Report New Problem
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-red-100 rounded-md p-3">
                <AlertCircle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Open Problems</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{openProblems.length}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <a
                href="#"
                onClick={(e) => { e.preventDefault(); navigate('/problems'); }}
                className="font-medium text-blue-900 hover:text-blue-800 flex items-center"
              >
                View all
                <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-yellow-100 rounded-md p-3">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">In Progress</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{inProgressProblems.length}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <a
                href="#"
                onClick={(e) => { e.preventDefault(); navigate('/problems'); }}
                className="font-medium text-blue-900 hover:text-blue-800 flex items-center"
              >
                View all
                <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">Resolved</dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900">{resolvedProblems.length}</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <a
                href="#"
                onClick={(e) => { e.preventDefault(); navigate('/problems'); }}
                className="font-medium text-blue-900 hover:text-blue-800 flex items-center"
              >
                View all
                <ArrowRight className="ml-1 h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div>
          <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-blue-900" />
            Recent Problems
          </h2>
          <div className="space-y-4">
            {recentProblems.map(problem => (
              <ProblemCard 
                key={problem.id} 
                problem={problem} 
                onClick={handleProblemClick} 
              />
            ))}
          </div>
          {recentProblems.length === 0 && (
            <div className="bg-white rounded-lg shadow-sm p-6 text-center">
              <p className="text-gray-500">No problems reported yet.</p>
            </div>
          )}
        </div>
        
        <div>
          <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-red-600" />
            High Priority Issues
          </h2>
          <div className="space-y-4">
            {priorityIssues.map(problem => (
              <ProblemCard 
                key={problem.id} 
                problem={problem} 
                onClick={handleProblemClick} 
              />
            ))}
          </div>
          {priorityIssues.length === 0 && (
            <div className="bg-white rounded-lg shadow-sm p-6 text-center">
              <p className="text-gray-500">No high priority issues currently.</p>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
          <BarChart2 className="h-5 w-5 mr-2 text-blue-900" />
          Problems by Department
        </h2>
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {Object.values(Department).map(dept => (
              <div key={dept} className="bg-gray-50 rounded-lg p-4 text-center">
                <h3 className="text-sm font-medium text-gray-500 capitalize">{dept}</h3>
                <p className="text-2xl font-bold text-blue-900 mt-2">{departmentCounts[dept] || 0}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;