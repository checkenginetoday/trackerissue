import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useProblems } from '../../context/ProblemsContext';
import ProblemDetailTabs from '../../components/Problems/ProblemDetailTabs';
import { ChevronLeft, Edit, Trash, Share } from 'lucide-react';

const ProblemDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { problems, loading } = useProblems();
  const navigate = useNavigate();
  const [problem, setProblem] = useState(null);

  useEffect(() => {
    if (!loading && id) {
      const foundProblem = problems.find(p => p.id === id);
      if (foundProblem) {
        setProblem(foundProblem);
      } else {
        // Problem not found, redirect to problems list
        navigate('/problems');
      }
    }
  }, [id, problems, loading, navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="loader">Loading...</div>
      </div>
    );
  }

  if (!problem) {
    return null;
  }

  return (
    <div>
      <div className="md:flex md:items-center md:justify-between mb-6">
        <div className="flex items-center">
          <button
            type="button"
            className="inline-flex items-center p-2 border border-transparent rounded-full bg-gray-100 text-gray-500 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            onClick={() => navigate('/problems')}
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <div className="ml-4">
            <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              {problem.title}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              Report #{problem.reportNumber || 'N/A'}
            </p>
          </div>
        </div>
        <div className="mt-4 flex space-x-3 md:mt-0">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Share className="-ml-1 mr-2 h-5 w-5 text-gray-500" />
            Share
          </button>
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Edit className="-ml-1 mr-2 h-5 w-5 text-gray-500" />
            Edit
          </button>
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
          >
            <Trash className="-ml-1 mr-2 h-5 w-5" />
            Delete
          </button>
        </div>
      </div>

      <ProblemDetailTabs problem={problem} />
    </div>
  );
};

export default ProblemDetail;