export enum ProblemStatus {
  OPEN = 'open',
  IN_PROGRESS = 'in_progress',
  RESOLVED = 'resolved',
}

export enum Department {
  ASSEMBLY = 'assembly',
  PAINT = 'paint',
  STAMPING = 'stamping',
  QUALITY = 'quality',
  LOGISTICS = 'logistics',
  MAINTENANCE = 'maintenance',
}

export enum UserRole {
  ADMIN = 'admin',
  SUPERVISOR = 'supervisor',
  ENGINEER = 'engineer',
  STANDARD = 'standard',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: Department;
  avatar?: string;
}

export interface Comment {
  id: string;
  problemId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  createdAt: Date;
}

export interface Attachment {
  id: string;
  problemId: string;
  name: string;
  type: string;
  url: string;
  uploadedBy: string;
  uploadedAt: Date;
}

export interface ActionItem {
  id: string;
  problemId: string;
  description: string;
  assignedTo: string;
  dueDate?: Date;
  status: 'pending' | 'completed';
  completedAt?: Date;
}

export interface Problem {
  id: string;
  title: string;
  description: string;
  department: Department;
  reportNumber?: string;
  status: ProblemStatus;
  priority: 'low' | 'medium' | 'high' | 'critical';
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  assignedTo?: string;
  rootCause?: string;
  solution?: string;
  comments?: Comment[];
  attachments?: Attachment[];
  actionItems?: ActionItem[];
  tags?: string[];
  impactLevel?: 'minor' | 'moderate' | 'major' | 'severe';
  recurrenceRate?: number;
  downtime?: number; // in minutes
}